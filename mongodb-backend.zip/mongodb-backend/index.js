require("dotenv").config();
const mongoose = require("mongoose");
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const cors = require("cors");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const bodyParser = require('body-parser');
const csv = require('csv-parser');
const app = express();  



// Multer configuration for file uploads
const upload = multer({ dest: "uploads/" });

// ✅ CORS Configuration (before app.listen)
const corsOptions = {
  origin: process.env.NODE_ENV === 'production' 
    ? 'http://192.168.56.237:3000' // For mobile device access
    : 'http://localhost:3000',   // For laptop/desktop browser access
  credentials: true,
  optionsSuccessStatus: 200,
};
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/barangay_db", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch(err => console.error("❌ Error connecting to MongoDB", err));

// MongoDB Models for User, Resident, and Officer
const User = mongoose.model('User', new mongoose.Schema({
  username: String,
  password: String,
  role: String
}));

// Add Resident Details
const Resident = mongoose.model('Resident', new mongoose.Schema({
  id: { type: String, required: true },
  firstName: String,
  middleInitial: String,
  lastName: String,
  street: String,
  purok: String,
  gender: String,
  age: String,
  birthDate: String,
  birthPlace: String,
  barangay: String,
  citizenship: String,
  civilStatus: String,
  religion: String,
  occupation: String,
  email: String,
  contactNumber: String,
  annualIncome: String,
  beneficiaryStatus: String,
  status: { type: String, default: "Active" }
})); 

const Officer = mongoose.model('Officer', new mongoose.Schema({
  id: { type: String, required: true },
  firstName: String,
  middleInitial: String,
  lastName: String,
  street: String,
  purok: String,
  barangay: String,
  gender: String,
  age: String,
  birthDate: String,
  birthPlace: String,
  citizenship: String,
  civilStatus: String,
  religion: String,
  occupation: String,
  email: String,
  contactNumber: String,
  role: String,
  annualIncome: String,
  beneficiaryStatus: String,
  status: { type: String, default: "Active" }
})); 

// Secret for JWT
const JWT_SECRET = process.env.JWT_SECRET || "admin123";

// Default users creation (for testing)
const createDefaultUsers = async () => {
  try {
    console.log("🔍 Checking if default users exist...");

    const defaultUsers = [
      { username: "admin", password: "admin123", role: "admin" },
      { username: "resident", password: "resident123", role: "resident" },
      { username: "officer", password: "officer123", role: "officer" }
    ];

    for (const userData of defaultUsers) {
      const userExists = await User.findOne({ username: userData.username });
      if (!userExists) {
        await User.create(userData);
        console.log(`✅ Default user created: ${userData.username}`);
      }
    }
  } catch (err) {
    console.error("❌ Error creating/fixing default users:", err);
  }
};

createDefaultUsers();

// User Login route
app.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({ username });

    if (!user || password !== user.password) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    const token = jwt.sign({ username: user.username, role: user.role }, JWT_SECRET, { expiresIn: "1h" });

    console.log("✅ Login successful:", username);
    res.json({ message: "Login successful", role: user.role, token });
  } catch (err) {
    console.error("❌ Internal Server Error:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Fetch Residents
app.get("/residents", async (req, res) => {
  try {
    const residents = await Resident.find();
    res.json(residents);
  } catch (err) {
    console.error("❌ Error fetching residents:", err);
    res.status(500).json({ message: "Failed to fetch residents" });
  }
});

app.post("/add-resident", async (req, res) => {
  console.log("Request Body:", req.body); // Debugging

  const { id, firstName, lastName, middleInitial, street, purok, gender, age, birthDate, birthPlace, barangay,
    citizenship, civilStatus, religion, occupation, email, contactNumber, annualIncome, beneficiaryStatus, status } = req.body;

  if (!id || !firstName || !lastName) {
    return res.status(400).json({ message: 'Missing required fields: ID, First Name, Last Name' });
  }

  try {
    const newResident = new Resident({
      id, firstName, lastName, middleInitial, street, purok, gender, age, birthDate, birthPlace, barangay,
      citizenship, civilStatus, religion, occupation, email, contactNumber, annualIncome, beneficiaryStatus, status
    });

    await newResident.save();
    res.status(201).json({ message: 'Resident added successfully' });
  } catch (error) {
    console.error('Error saving resident:', error);
    res.status(500).json({ message: 'Failed to save resident' });
  }
});


app.put("/update-resident/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    // Optional: validate that at least one field is being updated
    if (Object.keys(updatedData).length === 0) {
      return res.status(400).json({ message: "No data provided to update" });
    }

    const resident = await Resident.findOneAndUpdate({ id }, updatedData, {
      new: true,
      runValidators: true,
    });

    if (!resident) {
      return res.status(404).json({ message: "Resident not found" });
    }

    res.json({ message: "Resident updated successfully", updatedResident: resident });
  } catch (err) {
    console.error("❌ Error updating resident:", err);
    res.status(500).json({ message: "Failed to update resident", error: err.message });
  }
});


// Delete a Resident
app.delete("/delete-resident/:id", async (req, res) => {
  try {
    const { id } = req.params;
    // Find and delete the resident by their ID
    const resident = await Resident.findOneAndDelete({ id });

    if (!resident) {
      return res.status(404).json({ message: "Resident not found" });
    }

    // Respond with success message and the deleted resident's information
    res.json({
      message: "Resident deleted successfully",
      deletedResident: resident
    });
  } catch (err) {
    console.error("❌ Error deleting resident:", err);
    res.status(500).json({ message: "Failed to delete resident", error: err.message });
  }
});


// Add an Officer
app.post('/add-officer', async (req, res) => {
  const {
    id, firstName, lastName, middleInitial, street, purok, barangay, gender, age,
    birthDate, birthPlace, citizenship, civilStatus, religion, occupation, email,
    contactNumber, role, annualIncome, beneficiaryStatus, status
  } = req.body;

  // ✅ Basic validation
  if (!id || !firstName || !lastName) {
    return res.status(400).json({ message: 'Missing required fields: ID, First Name, Last Name' });
  }

  try {
    // ✅ Optional: Prevent duplicate officer with same ID
    const existingOfficer = await Officer.findOne({ id });
    if (existingOfficer) {
      return res.status(409).json({ message: 'Officer with this ID already exists' });
    }

    const newOfficer = new Officer({
      id, firstName, lastName, middleInitial, street, purok, barangay, gender, age,
      birthDate, birthPlace, citizenship, civilStatus, religion, occupation, email,
      contactNumber, role, annualIncome, beneficiaryStatus, status
    });

    await newOfficer.save();
    res.status(201).json({ message: '✅ Officer added successfully', officer: newOfficer });
  } catch (error) {
    console.error('❌ Error saving officer:', error);
    res.status(500).json({ message: 'Failed to save officer', error: error.message });
  }
});


// Fetch Officers
app.get("/officers", async (req, res) => {
  try {
    const officers = await Officer.find();
    res.status(200).json(officers);
  } catch (err) {
    console.error("❌ Error fetching officers:", err);
    res.status(500).json({ message: "Failed to fetch officers", error: err.message });
  }
});


// Update an Officer
app.put("/update-officer/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    // Optional: Check if update payload is empty
    if (!updatedData || Object.keys(updatedData).length === 0) {
      return res.status(400).json({ message: "No data provided to update" });
    }

    const officer = await Officer.findOneAndUpdate({ id }, updatedData, {
      new: true,
      runValidators: true, // Optional: run schema validation
    });

    if (!officer) {
      return res.status(404).json({ message: "❌ Officer not found" });
    }

    res.status(200).json({
      message: "✅ Officer updated successfully",
      updatedOfficer: officer,
    });
  } catch (err) {
    console.error("❌ Error updating officer:", err);
    res.status(500).json({
      message: "Failed to update officer",
      error: err.message,
    });
  }
});

// Delete an Officer
app.delete("/delete-officer/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const officer = await Officer.findOneAndDelete({ id });

    if (!officer) {
      return res.status(404).json({ message: "❌ Officer not found" });
    }

    res.status(200).json({
      message: "✅ Officer deleted successfully",
      deletedOfficer: officer
    });
  } catch (err) {
    console.error("❌ Error deleting officer:", err);
    res.status(500).json({
      message: "Failed to delete officer",
      error: err.message
    });
  }
});


// Get Counts of Residents and Officers and reports
app.get('/user-counts', async (req, res) => {
  try {
    const residentsCount = await Resident.countDocuments();
    const officersCount = await Officer.countDocuments();
    const reportsCount = await Report.countDocuments();

    res.json({
      residentsCount,
      officersCount,
      reportsCount
    });
  } catch (err) {
    console.error('Error fetching user counts:', err);
    res.status(500).json({ error: 'Failed to get user counts' });
  }
});

//homepage count
let homePageViewCount = 0;

app.get("/home-views", (req, res) => {
  homePageViewCount++;
  res.json({ views: homePageViewCount });
});

//Get residents details by ID
app.get('/api/residents/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const resident = await Resident.findOne({ id });

    if (!resident) {
      return res.status(404).json({ message: 'Resident not found' });
    }

    res.json(resident);
  } catch (error) {
    console.error('Error fetching resident:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get officer by ID
app.get('/api/officers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const officer = await Officer.findOne({ id });

    if (!officer) {
      return res.status(404).json({ message: 'Officer not found' });
    }

    res.json(officer);
  } catch (error) {
    console.error('Error fetching officer:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post("/api/generate-clearance", async (req, res) => {
  try {
    console.log("Received clearance request:", req.body);

    const { residentId } = req.body;
    if (!residentId) {
      return res.status(400).json({ error: "Resident ID is required" });
    }

    console.log("Fetching resident from MongoDB by ID:", residentId);
    const resident = await Resident.findOne({ id: residentId });

    if (!resident) {
      console.log("Resident not found in MongoDB:", residentId);
      return res.status(404).json({ error: "Resident not found" });
    }

    console.log("Resident data retrieved:", resident);

    const clearanceData = {
      fullName: `${resident.firstName} ${resident.lastName}`,
      address: `${resident.street}, Purok ${resident.purok}`,
      age: `${resident.age}`,
      status: "Cleared",
      issuedDate: new Date().toLocaleDateString(),
    };

    console.log("Clearance data:", clearanceData);
    res.json(clearanceData);
  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({ error: "Server error" });
  }
});

// Route for uploading residents CSV
app.post("/residents/upload-csv", upload.single("file"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  let results = [];

  fs.createReadStream(req.file.path)
    .pipe(csv())
    .on("data", (data) => results.push(data))
    .on("end", async () => {
      try {
        // Filter and clean data
        const validResidents = results
          .filter(resident => resident.id && resident.firstName && resident.lastName && resident.middleInitial)
          .map(resident => ({
            id: resident.id || "",
            firstName: resident.firstName || "",
            lastName: resident.lastName || "",
            middleInitial: resident.middleInitial || "",
            street: resident.street || "",
            purok: resident.purok || "",
            gender: resident.gender || "",
            age: resident.age || "",
            birthDate: resident.birthDate || "",
            birthPlace: resident.birthPlace || "",
            barangay: resident.barangay || "",
            citizenship: resident.citizenship || "",
            civilStatus: resident.civilStatus || "",
            religion: resident.religion || "",
            occupation: resident.occupation || "",
            email: resident.email || "",
            contactNumber: resident.contactNumber || "",
            annualIncome: resident.annualIncome || "",
            beneficiaryStatus: resident.beneficiaryStatus || "",
            status: resident.status || "Active",
          }));

        // Insert all valid residents into MongoDB
        await Resident.insertMany(validResidents);
        fs.unlinkSync(req.file.path); // Delete uploaded file
        res.json({ message: "CSV data uploaded and saved successfully", count: validResidents.length });
      } catch (error) {
        console.error("❌ Error saving CSV to MongoDB:", error);
        res.status(500).json({ message: "Failed to save residents to MongoDB" });
      }
    });
});

  // Fetch all residents' socioeconomic data

  app.get("/socioeconomic-data", async (req, res) => {
    try {
      // Fetch only relevant socioeconomic fields from MongoDB
      const residents = await Resident.find({}, {
        id: 1,
        firstName: 1,
        middleInitial: 1,
        lastName: 1,
        occupation: 1,
        annualIncome: 1,
        beneficiaryStatus: 1,
        _id: 0 // exclude MongoDB's _id field
      });
  
      if (!residents || residents.length === 0) {
        return res.status(404).json({ message: "No resident data found." });
      }
  
      const socioData = residents.map(resident => ({
        id: resident.id,
        firstName: resident.firstName,
        middleInitial: resident.middleInitial || "",
        lastName: resident.lastName,
        occupation: resident.occupation || "N/A",
        annualIncome: resident.annualIncome || 0,
        beneficiaryStatus: resident.beneficiaryStatus || "N/A",
      }));
  
      res.json(socioData);
    } catch (error) {
      console.error("❌ Error fetching socioeconomic data:", error);
      res.status(500).json({ message: "Server error retrieving data." });
    }
  });

  
  const { v4: uuidv4 } = require('uuid');

const reportSchema = new mongoose.Schema({
  reportId: {
    type: String,
    unique: true,
    required: true,
    default: () => uuidv4(),  // Generate a unique reportId using uuid
  },
  residentName: String,
  title: String,
  description: String,
  street: String,
  purok: String,
  status: {
    type: String,
    enum: ['Pending', 'Resolved'],
    default: 'Pending',
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Report = mongoose.model('Report', reportSchema);

app.post("/submit-report", async (req, res) => {
  const { title, description, residentName, street, purok } = req.body;

  if (!title || !description || !residentName || !street || !purok) {
    return res.status(400).json({ message: "All fields are required." });
  }

  try {
    const newReport = new Report({
      title,
      description,
      residentName,
      street,
      purok,
    });

    await newReport.save();

    res.status(200).json({ message: "Report submitted successfully." });
  } catch (err) {
    console.error("❌ Failed to insert report:", err);
    res.status(500).json({ message: "Server error." });
  }
});

  app.put('/api/reports/:id', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
  
    if (!status || !['Pending', 'Completed'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status value.' });
    }
  
    try {
      const report = await Report.findByIdAndUpdate(
        id,
        { status },
        { new: true }
      );
  
      if (!report) {
        return res.status(404).json({ message: 'Report not found.' });
      }
  
      res.json(report);
    } catch (error) {
      console.error("❌ Failed to update report:", error);
      res.status(500).json({ message: 'Failed to update report status' });
    }
  });

  app.get('/api/reports', async (req, res) => {
    try {
      const reports = await Report.find().sort({ createdAt: -1 });
  
      if (!reports || reports.length === 0) {
        return res.status(404).json({ message: "No reports found." });
      }
  
      res.json(reports);
    } catch (error) {
      console.error("❌ Error fetching reports:", error);
      res.status(500).json({ message: "Server error retrieving reports." });
    }
  });

  app.delete('/api/reports/:id', async (req, res) => {
    const { id } = req.params;
    const { residentName } = req.body;
  
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ message: 'Invalid report ID' });
    }
  
    if (!residentName) {
      return res.status(400).json({ message: 'Resident name is required to delete.' });
    }
  
    try {
      // Find the report by its ID and residentName
      const report = await Report.findOne({ _id: id, residentName });
  
      if (!report) {
        return res.status(404).json({ message: 'Report not found or resident name mismatch.' });
      }
  
      // Delete the report if the resident name matches
      await Report.findByIdAndDelete(id);
      res.json({ message: 'Report deleted successfully.' });
    } catch (err) {
      console.error("❌ Failed to delete report:", err);
      res.status(500).json({ message: 'Server error while deleting report.' });
    }
  });


 // ✅ Server listening
const PORT = process.env.PORT || 5000;
const HOST = '0.0.0.0'; // This is important for LAN access

app.listen(PORT, HOST, () => {
  console.log(`🚀 Server is running on http://192.168.56.237:${PORT}`);
});

 //✅ Start server
//app.listen(5000, () => {
 //  console.log("🚀 Backend is running on http://localhost:5000");
// });
